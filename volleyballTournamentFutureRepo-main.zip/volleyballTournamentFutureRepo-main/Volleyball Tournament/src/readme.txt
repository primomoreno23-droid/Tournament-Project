Ben's to do:
As a Tournament organizer, I would like to keep track of the wins and losses of each team entered.
DONE 10/1/2025 8:02pm

As a Tournament organizer, I would like to be able to designate the winner and loser of each tournament match, where the winner moves on.

As a Tournament organizer, I would like to have the teams seeded by win/loss records.
DONE 10/1/2025 11:54pm


As a Tournament organizer, I would like to be able to assign one of 4 courts to each match.



1
16
2
15
3
14
4
13
5
12
6
11
7
10
8
9

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16


