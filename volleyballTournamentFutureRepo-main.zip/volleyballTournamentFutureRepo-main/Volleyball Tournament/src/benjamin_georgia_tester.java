public class benjamin_georgia_tester {
    public static void main(String[] args) {

        temp_Team_Controller controller = new temp_Team_Controller();
        //
        // Team testTeam = new Team("primo's team",1,1,1);
        //System.out.println(testTeam);

    }
}
